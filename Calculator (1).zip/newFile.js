Array.from(buttons).forEach((button) => {
  button.addEventListener('click', (e) => {
    if (e.targer.innerHTML == "=") {
      string = eval(string);
      document.querySelector('input').value = string;
    }

    console.log(e.target);
    string = string + e.target.innerHTML;
    document.querySelector('input').value = string;

  });
});
